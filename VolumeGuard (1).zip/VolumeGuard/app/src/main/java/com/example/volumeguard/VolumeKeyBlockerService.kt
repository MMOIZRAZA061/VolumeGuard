package com.example.volumeguard

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Receives physical key events through Android's documented key-filter API
 * (FLAG_REQUEST_FILTER_KEY_EVENTS + onKeyEvent). Returning true from onKeyEvent
 * consumes the event so the system does not change the volume.
 *
 * Limits (see README): OEM firmware may behave differently, and this cannot stop the
 * hardware from generating events. It only ignores them.
 *
 * Optional "volume lock" backup: while enabled, a ContentObserver on system settings
 * restores your last app-set volumes. It is only registered while the lock is on.
 */
class VolumeKeyBlockerService : AccessibilityService() {

    data class State(
        val connected: Boolean = false,
        val blockedCount: Int = 0,
        val lastBlockedKey: String? = null,
        val lastBlockedAtMillis: Long = 0L
    )

    private val prefs by lazy { Prefs(applicationContext) }
    private val handler = Handler(Looper.getMainLooper())
    private var lockRegistered = false

    private val lockRunnable = Runnable { enforceLock() }

    private val settingsObserver = object : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean) {
            handler.removeCallbacks(lockRunnable)
            handler.postDelayed(lockRunnable, LOCK_DEBOUNCE_MS)
        }
    }

    // Held as a field because SharedPreferences keeps only a weak reference to listeners.
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.KEY_LOCK) syncLockObserver()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Belt and braces: make sure the key-filter flag is set even if the XML flag is ignored.
        serviceInfo?.let { info ->
            info.flags = info.flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            serviceInfo = info
        }
        prefs.register(prefListener)
        _state.update { it.copy(connected = true) }
        syncLockObserver()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        if (keyCode != KeyEvent.KEYCODE_VOLUME_UP && keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return false
        }
        if (!prefs.blockingEnabled) return false

        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            val name = if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) "Volume Up" else "Volume Down"
            _state.update {
                it.copy(
                    blockedCount = it.blockedCount + 1,
                    lastBlockedKey = name,
                    lastBlockedAtMillis = System.currentTimeMillis()
                )
            }
        }
        return true // consumed: Android will not act on this key event
    }

    // This service does not request any accessibility events.
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        teardown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun teardown() {
        stopLock()
        prefs.unregister(prefListener)
        _state.update { it.copy(connected = false) }
    }

    private fun syncLockObserver() {
        if (prefs.lockEnabled) startLock() else stopLock()
    }

    private fun startLock() {
        if (!lockRegistered) {
            contentResolver.registerContentObserver(Settings.System.CONTENT_URI, true, settingsObserver)
            lockRegistered = true
        }
        enforceLock()
    }

    private fun stopLock() {
        handler.removeCallbacks(lockRunnable)
        if (lockRegistered) {
            contentResolver.unregisterContentObserver(settingsObserver)
            lockRegistered = false
        }
    }

    private fun enforceLock() {
        if (!prefs.lockEnabled) return
        val controller = VolumeController(this)
        val ringerNormal = controller.soundMode() == SoundMode.SOUND
        for (stream in VolumeStream.values()) {
            if (!controller.isSupported(stream)) continue
            // Raising a ring-type volume would switch the phone out of vibrate/silent, so skip those.
            if (stream.tiedToRinger && !ringerNormal) continue
            if (controller.isMuted(stream)) continue
            val target = prefs.lockedLevel(stream) ?: continue
            if (controller.volume(stream) != target) {
                controller.setVolume(stream, target, remember = false)
            }
        }
    }

    companion object {
        private const val LOCK_DEBOUNCE_MS = 150L

        private val _state = MutableStateFlow(State())
        val state: StateFlow<State> = _state.asStateFlow()

        fun resetCounter() {
            _state.update { it.copy(blockedCount = 0, lastBlockedKey = null, lastBlockedAtMillis = 0L) }
        }

        /** True when the user has switched this service on in Android's Accessibility settings. */
        fun isEnabledInSettings(context: Context): Boolean {
            val enabled = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val me = ComponentName(context, VolumeKeyBlockerService::class.java)
            return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
        }
    }
}
