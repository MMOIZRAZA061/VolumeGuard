package com.example.volumeguard.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.volumeguard.FloatingPanelService
import com.example.volumeguard.Prefs
import com.example.volumeguard.SetResult
import com.example.volumeguard.SoundMode
import com.example.volumeguard.VolumeController
import com.example.volumeguard.VolumeKeyBlockerService
import com.example.volumeguard.VolumeStream
import java.text.DateFormat
import java.util.Date
import kotlin.math.roundToInt

private val StatusGreen = Color(0xFF2E7D32)
private val StatusAmber = Color(0xFFB26A00)
private val StatusRed = Color(0xFFC62828)

private data class StreamUi(
    val stream: VolumeStream,
    val min: Int,
    val max: Int,
    val current: Int,
    val muted: Boolean
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(lifecycle: Lifecycle) {
    val context = LocalContext.current
    val controller = remember { VolumeController(context) }
    val prefs = remember { Prefs(context) }

    // Bumping this re-reads everything from Android. It is bumped when the screen starts
    // (e.g. after returning from Settings) and whenever system volume settings change
    // while the screen is visible. The observer is removed as soon as the screen stops.
    var tick by remember { mutableIntStateOf(0) }

    DisposableEffect(lifecycle) {
        val handler = Handler(Looper.getMainLooper())
        val observer = object : ContentObserver(handler) {
            override fun onChange(selfChange: Boolean) {
                tick++
            }
        }
        var registered = false
        val lifecycleObserver = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_START) {
                if (!registered) {
                    context.contentResolver.registerContentObserver(
                        Settings.System.CONTENT_URI, true, observer
                    )
                    registered = true
                }
                tick++
            } else if (event == Lifecycle.Event.ON_STOP && registered) {
                context.contentResolver.unregisterContentObserver(observer)
                registered = false
            }
        }
        lifecycle.addObserver(lifecycleObserver)
        onDispose {
            lifecycle.removeObserver(lifecycleObserver)
            if (registered) context.contentResolver.unregisterContentObserver(observer)
        }
    }

    val serviceEnabled = remember(tick) { VolumeKeyBlockerService.isEnabledInSettings(context) }
    val overlayGranted = remember(tick) { Settings.canDrawOverlays(context) }
    val policyGranted = remember(tick) { controller.hasPolicyAccess() }
    val soundMode = remember(tick) { controller.soundMode() }
    val streams = remember(tick) {
        VolumeStream.values().filter { controller.isSupported(it) }.map {
            StreamUi(it, controller.minVolume(it), controller.maxVolume(it), controller.volume(it), controller.isMuted(it))
        }
    }
    val blocker by VolumeKeyBlockerService.state.collectAsState()

    var blockingEnabled by remember { mutableStateOf(prefs.blockingEnabled) }
    var lockEnabled by remember { mutableStateOf(prefs.lockEnabled) }
    var floatingEnabled by remember { mutableStateOf(prefs.floatingEnabled) }

    // The floating panel can be switched off from its notification, so re-sync on refresh.
    LaunchedEffect(tick) { floatingEnabled = prefs.floatingEnabled }

    fun toast(message: String) = Toast.makeText(context, message, Toast.LENGTH_LONG).show()

    fun report(result: SetResult) {
        when (result) {
            SetResult.OK -> Unit
            SetResult.NEEDS_POLICY_ACCESS ->
                toast("Android needs Do Not Disturb access for this change. Grant it in the Sound mode card.")
            SetResult.FAILED -> toast("Android refused this change on this phone.")
        }
        tick++
    }

    fun startFloating() {
        prefs.floatingEnabled = true
        floatingEnabled = true
        FloatingPanelService.start(context)
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { startFloating() } // the panel works even if notifications are denied

    fun setFloating(on: Boolean) {
        if (!on) {
            prefs.floatingEnabled = false
            floatingEnabled = false
            FloatingPanelService.stop(context)
            return
        }
        if (!Settings.canDrawOverlays(context)) {
            toast("Allow Display over other apps for Volume Guard, then come back and switch the panel on again.")
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startFloating()
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Volume Guard") }) }) { inner ->
        Column(
            modifier = Modifier
                .padding(inner)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ---------- 1. Physical key blocking ----------
            SectionCard("Physical volume keys") {
                val (statusText, statusColor) = when {
                    !serviceEnabled -> "Service is off. Nothing is being blocked." to StatusRed
                    !blocker.connected -> "Turned on in Settings but not connected yet. Nothing is being blocked." to StatusAmber
                    !blockingEnabled -> "Service is running, blocking is paused." to StatusAmber
                    else -> "Service is running and filtering the volume keys." to StatusGreen
                }
                StatusLine(statusText, statusColor)

                if (!serviceEnabled) {
                    Muted("Turn on Volume Guard key blocker in Accessibility settings. Android asks you to confirm because accessibility services are powerful. This one only receives key presses; it cannot read your screen.")
                    Button(onClick = { openAccessibilitySettings(context) }) { Text("Open accessibility settings") }
                } else {
                    if (!blocker.connected) {
                        Muted("If this stays amber, switch the service off and on again in Accessibility settings.")
                    }
                    SwitchRow(
                        title = "Block Volume Up and Down",
                        subtitle = "Presses are swallowed before Android changes the volume.",
                        checked = blockingEnabled,
                        onChange = {
                            blockingEnabled = it
                            prefs.blockingEnabled = it
                        }
                    )
                    Text(
                        "Presses blocked: ${blocker.blockedCount}",
                        style = MaterialTheme.typography.titleMedium
                    )
                    if (blocker.lastBlockedKey != null) {
                        Muted("Last: ${blocker.lastBlockedKey} at ${DateFormat.getTimeInstance().format(Date(blocker.lastBlockedAtMillis))}")
                    } else {
                        Muted("No press seen yet. Press a volume button to test. If the counter rises and the volume does not change, blocking works on your phone. If the volume changes and the counter stays at 0, your phone is not letting this service intercept the keys. Use Volume lock below.")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { VolumeKeyBlockerService.resetCounter() }) { Text("Reset counter") }
                        OutlinedButton(onClick = { openAccessibilitySettings(context) }) { Text("Accessibility settings") }
                    }
                }
            }

            // ---------- 2. Sliders ----------
            SectionCard("Volume") {
                if (streams.isEmpty()) {
                    Muted("This phone reports fixed volume, so Android does not allow volume changes here.")
                }
                streams.forEach { ui ->
                    StreamRow(
                        ui = ui,
                        onLevel = { level -> if (level != ui.current) report(controller.setVolume(ui.stream, level)) },
                        onMute = { mute ->
                            val result = controller.setMuted(ui.stream, mute)
                            if (result == SetResult.OK && controller.isMuted(ui.stream) != mute) {
                                toast("${ui.stream.label} cannot be ${if (mute) "muted" else "unmuted"} on this phone.")
                            }
                            report(result)
                        }
                    )
                }
                Muted("Sliders change the real system volume immediately. On many phones Notification and System volume follow Ring, so moving one can move the others.")
            }

            // ---------- 3. Sound mode ----------
            SectionCard("Sound mode") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SoundMode.values().forEach { mode ->
                        FilterChip(
                            selected = soundMode == mode,
                            onClick = { report(controller.setSoundMode(mode)) },
                            label = { Text(mode.label) }
                        )
                    }
                }
                if (!policyGranted) {
                    Muted("Silent mode needs Do Not Disturb access. Vibrate and Sound may work without it, depending on the phone. To grant it: tap the button, find Volume Guard in the list and switch it on.")
                    OutlinedButton(onClick = {
                        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                    }) { Text("Grant Do Not Disturb access") }
                } else {
                    Muted("Do Not Disturb access is granted.")
                }
            }

            // ---------- 4. Floating panel ----------
            SectionCard("Floating volume panel") {
                SwitchRow(
                    title = "Show floating bubble",
                    subtitle = "Tap the bubble for a compact volume controller. Drag it to move it.",
                    checked = floatingEnabled && overlayGranted,
                    onChange = { setFloating(it) }
                )
                if (!overlayGranted) {
                    Muted("This needs the Display over other apps permission. Android shows its settings page when you switch the bubble on. It is requested only for this feature.")
                }
                Muted("To stay on screen, the bubble runs as a foreground service with a permanent notification. It does no work while you are not touching it, but phones with aggressive battery managers (including many itel/HiOS builds) may close it. Set Volume Guard to unrestricted battery use and lock it in the recent apps list to keep it alive.")
                OutlinedButton(onClick = {
                    context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }) { Text("Open battery optimisation settings") }
            }

            // ---------- 5. Volume lock ----------
            SectionCard("Volume lock (backup)") {
                SwitchRow(
                    title = "Restore my volumes",
                    subtitle = "Use this if the key blocker does not work on your phone.",
                    checked = lockEnabled,
                    onChange = { on ->
                        if (on) {
                            // Snapshot current levels as the ones to protect.
                            val ringerNormal = controller.soundMode() == SoundMode.SOUND
                            VolumeStream.values().forEach { s ->
                                if (controller.isSupported(s) && (!s.tiedToRinger || ringerNormal)) {
                                    prefs.setLockedLevel(s, controller.volume(s))
                                }
                            }
                        }
                        lockEnabled = on
                        prefs.lockEnabled = on
                    }
                )
                Muted("While the accessibility service is running, Volume Guard watches for volume changes and puts each stream back to the level you last set here. The volume may blip for a moment first, and changes you make from other places are reverted too. Switch it off when you want to change volume elsewhere. It does nothing unless the accessibility service is running.")
            }

            // ---------- 6. Honest limits ----------
            SectionCard("What this app cannot do") {
                Muted("Volume Guard cannot disable the hardware. A faulty or shorted button keeps sending signals to the phone. This app can only ask Android to ignore them. Android does not guarantee that every phone, in every state, passes key presses to accessibility services. Behaviour with the screen off, during calls or on the lock screen can differ, so test it.")
                Muted("A stuck button can still interfere with button combinations, and it keeps working below Android when the phone is off, in recovery or in the boot menu. The real fix is repair: a service centre can clean or replace the volume key flex or switch.")
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

private fun openAccessibilitySettings(context: Context) {
    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun StatusLine(text: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(12.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun Muted(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Muted(subtitle)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun StreamRow(ui: StreamUi, onLevel: (Int) -> Unit, onMute: (Boolean) -> Unit) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "${ui.stream.emoji}  ${ui.stream.label}",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f)
            )
            Text(
                "${ui.current} / ${ui.max}" + if (ui.muted) "  muted" else "",
                style = MaterialTheme.typography.bodyMedium
            )
            TextButton(onClick = { onMute(!ui.muted) }) { Text(if (ui.muted) "Unmute" else "Mute") }
        }
        if (ui.max > ui.min) {
            Slider(
                value = ui.current.toFloat(),
                onValueChange = { onLevel(it.roundToInt()) },
                valueRange = ui.min.toFloat()..ui.max.toFloat(),
                steps = (ui.max - ui.min - 1).coerceAtLeast(0)
            )
        }
    }
}
