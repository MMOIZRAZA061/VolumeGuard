package com.example.volumeguard

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.volumeguard.ui.DashboardScreen
import com.example.volumeguard.ui.VolumeGuardTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VolumeGuardTheme {
                DashboardScreen(lifecycle = lifecycle)
            }
        }
    }
}
