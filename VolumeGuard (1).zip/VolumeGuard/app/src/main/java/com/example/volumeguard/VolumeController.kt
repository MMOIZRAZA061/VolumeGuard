package com.example.volumeguard

import android.app.NotificationManager
import android.content.Context
import android.media.AudioManager
import android.os.Build

enum class VolumeStream(
    val streamType: Int,
    val label: String,
    val emoji: String,
    /** True when Android ties this stream to the ringer mode (sound / vibrate / silent). */
    val tiedToRinger: Boolean
) {
    MEDIA(AudioManager.STREAM_MUSIC, "Media", "\uD83C\uDFB5", false),
    RING(AudioManager.STREAM_RING, "Ring", "\uD83D\uDCDE", true),
    NOTIFICATION(AudioManager.STREAM_NOTIFICATION, "Notification", "\uD83D\uDD14", true),
    ALARM(AudioManager.STREAM_ALARM, "Alarm", "\u23F0", false),
    SYSTEM(AudioManager.STREAM_SYSTEM, "System", "\u2699\uFE0F", true)
}

enum class SoundMode(val label: String, val ringerMode: Int) {
    SOUND("Sound", AudioManager.RINGER_MODE_NORMAL),
    VIBRATE("Vibrate", AudioManager.RINGER_MODE_VIBRATE),
    SILENT("Silent", AudioManager.RINGER_MODE_SILENT)
}

enum class SetResult { OK, NEEDS_POLICY_ACCESS, FAILED }

/** Thin wrapper over AudioManager. Every call here is a public, documented Android API. */
class VolumeController(context: Context) {

    private val appContext = context.applicationContext
    private val audio = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val notificationManager =
        appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val prefs = Prefs(appContext)

    fun isSupported(stream: VolumeStream): Boolean =
        !audio.isVolumeFixed && maxVolume(stream) > 0

    fun maxVolume(stream: VolumeStream): Int = audio.getStreamMaxVolume(stream.streamType)

    fun minVolume(stream: VolumeStream): Int =
        if (Build.VERSION.SDK_INT >= 28) audio.getStreamMinVolume(stream.streamType) else 0

    fun volume(stream: VolumeStream): Int = audio.getStreamVolume(stream.streamType)

    fun isMuted(stream: VolumeStream): Boolean = audio.isStreamMute(stream.streamType)

    /**
     * Sets the real system volume immediately (no system volume panel).
     * [remember] stores the value as the level the optional volume lock should restore.
     */
    fun setVolume(stream: VolumeStream, level: Int, remember: Boolean = true): SetResult {
        val target = level.coerceIn(minVolume(stream), maxVolume(stream))
        return try {
            if (target > 0 && isMuted(stream)) {
                audio.adjustStreamVolume(stream.streamType, AudioManager.ADJUST_UNMUTE, 0)
            }
            audio.setStreamVolume(stream.streamType, target, 0)
            if (remember) prefs.setLockedLevel(stream, audio.getStreamVolume(stream.streamType))
            SetResult.OK
        } catch (e: SecurityException) {
            // Android blocks some changes (for example ring to 0) under Do Not Disturb rules.
            SetResult.NEEDS_POLICY_ACCESS
        }
    }

    fun setMuted(stream: VolumeStream, muted: Boolean): SetResult = try {
        audio.adjustStreamVolume(
            stream.streamType,
            if (muted) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE,
            0
        )
        SetResult.OK
    } catch (e: SecurityException) {
        SetResult.NEEDS_POLICY_ACCESS
    }

    fun soundMode(): SoundMode = when (audio.ringerMode) {
        AudioManager.RINGER_MODE_NORMAL -> SoundMode.SOUND
        AudioManager.RINGER_MODE_VIBRATE -> SoundMode.VIBRATE
        else -> SoundMode.SILENT
    }

    fun hasPolicyAccess(): Boolean = notificationManager.isNotificationPolicyAccessGranted

    fun setSoundMode(mode: SoundMode): SetResult {
        if (mode == SoundMode.SILENT && !hasPolicyAccess()) return SetResult.NEEDS_POLICY_ACCESS
        return try {
            audio.ringerMode = mode.ringerMode
            if (audio.ringerMode == mode.ringerMode) SetResult.OK else SetResult.FAILED
        } catch (e: SecurityException) {
            SetResult.NEEDS_POLICY_ACCESS
        }
    }
}
