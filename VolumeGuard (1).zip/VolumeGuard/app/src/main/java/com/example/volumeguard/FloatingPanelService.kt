package com.example.volumeguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlin.math.abs

/**
 * Optional floating volume bubble. Runs as a foreground service (required so Android keeps
 * it alive) and draws with SYSTEM_ALERT_WINDOW. Tap the bubble for a compact controller,
 * drag it to move it. Overlay views use classic Android Views because Compose needs extra
 * lifecycle plumbing inside a Service.
 */
class FloatingPanelService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var controller: VolumeController
    private lateinit var prefs: Prefs

    private var bubble: TextView? = null
    private var panel: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        controller = VolumeController(this)
        prefs = Prefs(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            prefs.floatingEnabled = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (!enterForeground()) {
            prefs.floatingEnabled = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            prefs.floatingEnabled = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (bubble == null) addBubble()
        // Not sticky: if Android kills the service, it stays off until you switch it on again
        // (or restart the phone) instead of being relaunched unpredictably in the background.
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        removePanel()
        removeBubble()
        super.onDestroy()
    }

    // ---------- foreground notification ----------

    private fun enterForeground(): Boolean = try {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        true
    } catch (e: Exception) {
        false
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Floating volume panel", NotificationManager.IMPORTANCE_LOW)
        )
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingPanelService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_stat_volume), "Turn off", stopIntent
        ).build()
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_volume)
            .setContentTitle("Floating volume panel is on")
            .setContentText("Tap to open Volume Guard")
            .setContentIntent(openIntent)
            .addAction(stopAction)
            .setOngoing(true)
            .build()
    }

    // ---------- bubble ----------

    private fun addBubble() {
        val size = dp(52)
        val view = TextView(this).apply {
            text = "\uD83D\uDD0A"
            textSize = 22f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xE60F4C4C.toInt())
            }
            elevation = dp(6).toFloat()
        }
        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (prefs.floatX >= 0) prefs.floatX else dp(8)
            y = if (prefs.floatY >= 0) prefs.floatY else dp(240)
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        view.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var downRawX = 0f
            private var downRawY = 0f
            private var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        downRawX = e.rawX
                        downRawY = e.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - downRawX).toInt()
                        val dy = (e.rawY - downRawY).toInt()
                        if (abs(dx) > slop || abs(dy) > slop) moved = true
                        if (moved) {
                            params.x = (startX + dx).coerceAtLeast(0)
                            params.y = (startY + dy).coerceAtLeast(0)
                            try {
                                windowManager.updateViewLayout(v, params)
                            } catch (ignored: IllegalArgumentException) {
                            }
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) {
                            prefs.floatX = params.x
                            prefs.floatY = params.y
                        } else {
                            v.performClick()
                            togglePanel()
                        }
                        return true
                    }
                }
                return false
            }
        })

        try {
            windowManager.addView(view, params)
            bubble = view
        } catch (e: Exception) {
            // Overlay permission revoked or window refused: switch the feature off cleanly.
            prefs.floatingEnabled = false
            stopSelf()
        }
    }

    private fun removeBubble() {
        bubble?.let {
            try {
                windowManager.removeView(it)
            } catch (ignored: IllegalArgumentException) {
            }
        }
        bubble = null
    }

    // ---------- compact controller ----------

    private fun togglePanel() {
        if (panel == null) showPanel() else removePanel()
    }

    private fun showPanel() {
        val white = 0xFFFFFFFF.toInt()
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
        }

        val title = TextView(this).apply {
            text = "Volume"
            textSize = 18f
            setTextColor(white)
        }
        val close = TextView(this).apply {
            text = "\u2715"
            textSize = 18f
            setTextColor(white)
            setPadding(dp(12), dp(4), dp(4), dp(4))
            setOnClickListener { removePanel() }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(close)
        }
        content.addView(header)

        for (stream in VolumeStream.values()) {
            if (controller.isSupported(stream)) addStreamRow(content, stream)
        }
        addModeRow(content)

        val root = ScrollView(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(0xF2182628.toInt())
            }
            clipToOutline = true
            addView(content)
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_OUTSIDE) {
                    removePanel()
                    true
                } else {
                    false
                }
            }
        }

        val params = WindowManager.LayoutParams(
            dp(300),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        try {
            windowManager.addView(root, params)
            panel = root
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open the volume panel.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun removePanel() {
        panel?.let {
            try {
                windowManager.removeView(it)
            } catch (ignored: IllegalArgumentException) {
            }
        }
        panel = null
    }

    private fun addStreamRow(parent: LinearLayout, stream: VolumeStream) {
        val white = 0xFFFFFFFF.toInt()
        val label = TextView(this).apply {
            setTextColor(white)
            textSize = 14f
        }
        val muteButton = TextView(this).apply {
            textSize = 18f
            setPadding(dp(12), dp(4), dp(4), dp(4))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, 0)
            addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(muteButton)
        }
        val seek = SeekBar(this).apply {
            min = controller.minVolume(stream)
            max = controller.maxVolume(stream)
            progress = controller.volume(stream)
        }

        fun render() {
            val muted = controller.isMuted(stream)
            label.text = "${stream.emoji}  ${stream.label}   ${seek.progress}/${seek.max}" +
                if (muted) "  (muted)" else ""
            muteButton.text = if (muted) "\uD83D\uDD07" else "\uD83D\uDD08"
        }

        muteButton.setOnClickListener {
            handle(controller.setMuted(stream, !controller.isMuted(stream)))
            render()
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    handle(controller.setVolume(stream, progress))
                    val actual = controller.volume(stream)
                    if (actual != progress) sb?.progress = actual
                }
                render()
            }

            override fun onStartTrackingTouch(sb: SeekBar?) = Unit
            override fun onStopTrackingTouch(sb: SeekBar?) = Unit
        })

        parent.addView(header)
        parent.addView(
            seek,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
        render()
    }

    private fun addModeRow(parent: LinearLayout) {
        val modeLabel = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
            setPadding(0, dp(16), 0, dp(4))
        }
        fun render() {
            modeLabel.text = "Sound mode: ${controller.soundMode().label}"
        }

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (mode in SoundMode.values()) {
            val button = Button(this).apply {
                text = mode.label
                isAllCaps = false
                setOnClickListener {
                    handle(controller.setSoundMode(mode))
                    render()
                }
            }
            row.addView(button, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        parent.addView(modeLabel)
        parent.addView(row)
        render()
    }

    private fun handle(result: SetResult) {
        val message = when (result) {
            SetResult.OK -> return
            SetResult.NEEDS_POLICY_ACCESS ->
                "Android needs Do Not Disturb access for this change. Grant it in Volume Guard."
            SetResult.FAILED -> "Android refused this change."
        }
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val CHANNEL_ID = "floating_panel"
        private const val NOTIFICATION_ID = 1001
        private const val ACTION_STOP = "com.example.volumeguard.action.STOP_FLOATING"

        fun start(context: Context) {
            ContextCompat.startForegroundService(
                context, Intent(context, FloatingPanelService::class.java)
            )
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, FloatingPanelService::class.java))
        }
    }
}
