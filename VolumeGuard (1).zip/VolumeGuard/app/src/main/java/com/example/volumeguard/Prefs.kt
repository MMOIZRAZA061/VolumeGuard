package com.example.volumeguard

import android.content.Context
import android.content.SharedPreferences

/** Small local settings store. Nothing leaves the phone. */
class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    /** When false, the accessibility service lets volume keys through untouched. */
    var blockingEnabled: Boolean
        get() = sp.getBoolean(KEY_BLOCKING, true)
        set(value) { sp.edit().putBoolean(KEY_BLOCKING, value).apply() }

    /** Backup mode: restore the volumes you last set in the app if something changes them. */
    var lockEnabled: Boolean
        get() = sp.getBoolean(KEY_LOCK, false)
        set(value) { sp.edit().putBoolean(KEY_LOCK, value).apply() }

    var floatingEnabled: Boolean
        get() = sp.getBoolean(KEY_FLOATING, false)
        set(value) { sp.edit().putBoolean(KEY_FLOATING, value).apply() }

    var floatX: Int
        get() = sp.getInt(KEY_FLOAT_X, -1)
        set(value) { sp.edit().putInt(KEY_FLOAT_X, value).apply() }

    var floatY: Int
        get() = sp.getInt(KEY_FLOAT_Y, -1)
        set(value) { sp.edit().putInt(KEY_FLOAT_Y, value).apply() }

    fun lockedLevel(stream: VolumeStream): Int? {
        val key = lockedKey(stream)
        return if (sp.contains(key)) sp.getInt(key, 0) else null
    }

    fun setLockedLevel(stream: VolumeStream, level: Int) {
        sp.edit().putInt(lockedKey(stream), level).apply()
    }

    fun register(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        sp.registerOnSharedPreferenceChangeListener(listener)
    }

    fun unregister(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        sp.unregisterOnSharedPreferenceChangeListener(listener)
    }

    private fun lockedKey(stream: VolumeStream) = "locked_level_${stream.name}"

    companion object {
        private const val FILE_NAME = "volume_guard_prefs"
        const val KEY_BLOCKING = "blocking_enabled"
        const val KEY_LOCK = "lock_enabled"
        const val KEY_FLOATING = "floating_enabled"
        const val KEY_FLOAT_X = "float_x"
        const val KEY_FLOAT_Y = "float_y"
    }
}
