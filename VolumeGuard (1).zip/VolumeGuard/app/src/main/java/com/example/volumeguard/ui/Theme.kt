package com.example.volumeguard.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColors = lightColorScheme(
    primary = Color(0xFF0F5F5F),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFBFEDEA),
    secondary = Color(0xFF8A4B2A),
    background = Color(0xFFF6F8F7),
    surface = Color(0xFFF6F8F7)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7FD6D0),
    onPrimary = Color(0xFF003736),
    primaryContainer = Color(0xFF0F4C4C),
    secondary = Color(0xFFFFB68F),
    background = Color(0xFF101414),
    surface = Color(0xFF101414)
)

@Composable
fun VolumeGuardTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colors = when {
        Build.VERSION.SDK_INT >= 31 ->
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        darkTheme -> DarkColors
        else -> LightColors
    }
    MaterialTheme(colorScheme = colors, content = content)
}
