package com.example.volumeguard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * After a restart, brings the floating panel back only if you had it switched on and the
 * overlay permission is still granted. The accessibility service is restored by Android itself.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = Prefs(context)
        if (prefs.floatingEnabled && Settings.canDrawOverlays(context)) {
            try {
                FloatingPanelService.start(context)
            } catch (e: Exception) {
                prefs.floatingEnabled = false
            }
        }
    }
}
