# Volume Guard

Kotlin + Jetpack Compose (Material 3) app for Android 8.0+ (built and targeted for Android 13 on an itel S667LN).
Blocks physical Volume Up/Down presses where Android allows it, and gives you on-screen volume controls.
Everything runs locally. No root, no hidden APIs, no network, no API keys.

## Honest summary

Android has one supported way for a normal app to intercept hardware keys: an AccessibilityService that declares
`canRequestFilterKeyEvents` and `FLAG_REQUEST_FILTER_KEY_EVENTS`, then returns `true` from `onKeyEvent`.
Volume Guard uses exactly that. It is a documented API and it works on stock Android 13.

What is NOT guaranteed:
- OEM firmware (including itel/HiOS) may treat volume keys specially. I could not test on your phone. The in-app
  "Presses blocked" counter tells you the truth: if it goes up and volume does not change, blocking works.
  If volume changes and the counter stays 0, the phone is not delivering the keys to the service.
- Behaviour with screen off, on the lock screen or during calls can differ from screen-on use.
- A shorted button still sends hardware signals. Software can only ignore them. It cannot stop them, and it cannot
  help when the phone is off, in recovery or in the boot menu. The real fix is repair (clean/replace the volume
  key switch or flex at a service centre).

Closest legitimate workaround, built in: **Volume lock (backup)**. While the accessibility service runs, it watches
system volume settings and restores the levels you last set in the app. It can flicker briefly and also reverts
volume changes from elsewhere. It is only active when switched on.

## Support matrix

| Requirement | Status |
|---|---|
| Intercept volume keys with AccessibilityService | Supported API; works on stock Android 13; not guaranteed on every OEM or screen state |
| Keep blocking in background | Supported. Android keeps enabled accessibility services running; no extra background work is done |
| Enable/disable switch | Supported (in-app switch; the service then passes keys through) |
| Per-stream sliders (media, ring, notification, alarm) | Supported via AudioManager |
| System volume | Supported where the phone exposes it; often linked to Ring |
| Mute/unmute | Supported via ADJUST_MUTE/UNMUTE; some phones ignore it for some streams (app tells you) |
| Sound/Vibrate/Silent | Silent needs Do Not Disturb access (user grants in Settings); Vibrate/Sound may work without |
| Floating panel | Supported with Display over other apps permission, foreground service and notification |
| Survive restart | Accessibility service: restored by Android. Floating panel: restored by BootReceiver if it was on |
| Disable the hardware itself | Impossible without root or repair |

## Project tree

```
VolumeGuard/
  settings.gradle.kts
  build.gradle.kts
  gradle.properties
  gradle/wrapper/gradle-wrapper.properties
  app/
    build.gradle.kts
    src/main/
      AndroidManifest.xml
      java/com/example/volumeguard/
        MainActivity.kt
        Prefs.kt
        VolumeController.kt
        VolumeKeyBlockerService.kt
        FloatingPanelService.kt
        BootReceiver.kt
        ui/Theme.kt
        ui/DashboardScreen.kt
      res/
        xml/volume_key_service_config.xml
        values/strings.xml, colors.xml, themes.xml
        values-night/themes.xml
        drawable/ic_launcher_foreground.xml, ic_stat_volume.xml
        mipmap-anydpi-v26/ic_launcher.xml, ic_launcher_round.xml
```

## Build and install

1. Install Android Studio (Koala 2024.1.1 or newer) with JDK 17 (bundled).
2. Unzip, then File > Open and pick the `VolumeGuard` folder. Let Gradle sync. It downloads Gradle 8.7 and
   dependencies, so you need internet once. If Studio offers to update the Android Gradle Plugin, you can accept.
   The project has no `gradlew` script or wrapper jar (they are binary). Studio uses the wrapper properties file
   and downloads Gradle itself.
3. On the phone: Settings > About phone > tap Build number 7 times. Then Developer options > turn on USB debugging.
4. Connect by USB, accept the debugging prompt, pick the phone in Studio's device menu, press Run.
   Or Build > Build APK(s), then copy `app/build/outputs/apk/debug/app-debug.apk` to the phone and open it
   (allow install from that source).

## Enable and test

1. Open Volume Guard. In "Physical volume keys" tap Open accessibility settings.
2. Find Volume Guard key blocker (may be under Installed/Downloaded apps, or Additional settings on itel), switch it on, confirm.
3. If the switch is greyed out with a "restricted setting" message (can happen for APKs installed by file manager):
   Settings > Apps > Volume Guard > three-dot menu > Allow restricted settings, then retry.
4. Back in the app the dot should turn green. Press Volume Up/Down. Check:
   - counter rises and volume does not change: blocking works
   - volume changes and counter stays 0: key interception is not available; turn on Volume lock
5. Test again with the screen off and on the lock screen, and with the app closed from recents.
6. Test sliders, mute, sound mode and the floating bubble.

## Troubleshooting (Android 13 and itel/HiOS)

- Service switches itself off or the dot goes amber: lock Volume Guard in recent apps, set battery to
  Unrestricted/No restrictions, and allow autostart/background activity in the phone manager if present.
  Then toggle the accessibility service off and on.
- Counter stays 0 while volume changes: the firmware does not pass those keys to accessibility services.
  Use Volume lock and plan for repair.
- Silent mode does nothing: grant Do Not Disturb access (Sound mode card button).
- Ring slider cannot reach 0: Android may need Do Not Disturb access for that.
- Floating bubble missing: grant Display over other apps; on Android 13 allow notifications so you can see/stop the
  service from its notification; some itel builds also have a separate "Pop-ups/floating windows" setting.
- Bubble disappears after a while: the battery manager closed it; apply the battery steps above.
- Gradle sync fails: check internet, use JDK 17, update AGP via the Studio prompt.
- Uninstall: switch the accessibility service off first, then uninstall.

## Privacy

The accessibility service requests no window content and no events. It sees only key events and ignores everything
except Volume Up/Down. Nothing is stored apart from your switches and last-set volumes on the phone.
